This is assignment 3 created by Howard Han and Boyang Lin. It shows in different majors, how the Total number of people with major， Male graduates， Female graduates， Women as a share of total， employed Number distributed，median salary and related by using the menu and color legend. You can do the comparison by selecting the menu and seeing different majors by hovering on the color legend. It clearly shows the relationship of different majors' conditions like how many employees do they have. Also, it can help to explore the correlation of different data. 


The data set we use is:https://github.com/fivethirtyeight/data/tree/master/college-majors.
We processed the data by classifying and merging the categories of university majors to make the visualization more clear and readable.

And the original version of this visualization is from an online course:https://www.youtube.com/watch?v=Ig_C5lDTuq4&list=PL9yYRbwpkykuK6LSMLH3bAaPpXaDUXcLV&index=36, which creates a visualization of: https://vizhub.com/curran/8b699c4000704216a709adfeb38f2411. So you can directly see what we changed. 

As for the development process. Since both of us don't know about coding, so the most time is spent watching tutorials for like 10-12 hours. However, it is not enough for us to create a visualization from start, so we decided to refine an existed data vis. We spent 3-5 hours to comprehensive this data visualization, 1 hour to find the dataset, and 5 hours to make changes. And for all the steps, we kind of work together, so the workload can be divide